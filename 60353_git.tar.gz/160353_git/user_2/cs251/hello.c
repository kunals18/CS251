#include<stdio.h>
void m_sendmsg(char *);
void m_getmsg(char *);
void main(){
printf("Helloworld!\n");
printf("This must be a monolithic design\n");
m_sendmsg("is more portable");
}
void m_sendmsg(char *a){
print("microkernel: s\n",a);
}
void m_getmsg(char *b){
//TODO: getmsg feature
}
