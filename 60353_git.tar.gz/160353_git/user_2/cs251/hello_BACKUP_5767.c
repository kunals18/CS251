#include<stdio.h>
void microkernel_sendmsg(char *);
void main(){
printf("Helloworld!\n");
<<<<<<< HEAD
microkernel_sendmsg("is more portable");
}
microkernel_sendmsg(char *a){
printf("microkernel: %s\n",a);
=======
printf("This must be a monolithic design\n");
>>>>>>> 74a3c2fac8d2b5181bf6bd4936d802588d84e650
}
